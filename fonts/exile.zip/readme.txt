========================================
MYST III: Exile - the Logo Font
========================================
Version 1.2		May, 2001
----------------------------------------
Michael Bower - AgesOfMYST@aol.com
----------------------------------------
   http://members.aol.com/agesofmyst
----------------------------------------

To install the MYST III: Exile font onto
your computer, simply open your fonts
folder (c:\windows\fonts) for Microsoft
Windows 9x/ME and (c:\winnt\fonts) for
2000. Select "Install new font" from the
file menu.  Tada!

----------------------------------------
NOTES ABOUT THE MYST III: Exile font
----------------------------------------

========================================
========================================
What's different from version 1.01b

The glyphs were touched up to look
smoother and more like the real logo.

Version 1.2-the "X" was fixed to look
less rigid.
========================================
========================================

The "real" version of the Exile font is
a modified version of Adobe Garamond.
All characters in this version are
identical to Adobe Garamond with the
exception of "E","X","I" and "L", which
have been modified to look like the
logo's.

----------------------------------------
For more information and updates please 
visit: http://members.aol.com/agesofmyst
----------------------------------------


